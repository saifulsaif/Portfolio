-- phpMyAdmin SQL Dump
-- version 4.2.7.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: May 14, 2017 at 05:37 PM
-- Server version: 5.6.20
-- PHP Version: 5.5.15

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `portfolio`
--

-- --------------------------------------------------------

--
-- Table structure for table `about`
--

CREATE TABLE IF NOT EXISTS `about` (
`about_id` int(23) NOT NULL,
  `photo` varchar(55) NOT NULL,
  `title` varchar(55) NOT NULL,
  `description` text NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=10 ;

--
-- Dumping data for table `about`
--

INSERT INTO `about` (`about_id`, `photo`, `title`, `description`) VALUES
(9, 'http://localhost/Portfolio/assets/img/dddd.jpg', 'Hello, I am Saiful', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus ultrices, nulla et egestas venenatis, urna ante tincidunt erat, vitae lacinia ante urna dignissim purus. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Nam diam purus, facilisis eu placerat vel, egestas vel massa. Phasellus pharetra urna at sem convallis bibendum. Fusce sed leo quis purus luctus tempus. Ut ornare mattis justo. Ut vestibulum, leo vel interdum efficitur, felis tellus semper elit, et efficitur erat felis vel lectus. Pellentesque a purus aliquet, lacinia odio sit amet, fringilla ligula. Pellentesque lectus libero, lobortis sed quam in, congue elementum tellus. Vestibulum dui enim, aliquet in tellus id, luctus tristique velit. Mauris augue sapien, condimentum sed ligula sit amet, facilisis aliquet nulla ');

-- --------------------------------------------------------

--
-- Table structure for table `contact`
--

CREATE TABLE IF NOT EXISTS `contact` (
`contact_id` int(33) NOT NULL,
  `full_name` varchar(50) NOT NULL,
  `email_address` varchar(111) NOT NULL,
  `subject` varchar(55) NOT NULL,
  `message` text NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=9 ;

--
-- Dumping data for table `contact`
--

INSERT INTO `contact` (`contact_id`, `full_name`, `email_address`, `subject`, `message`) VALUES
(7, 'Md.Saiful Islam', 'saifulsaif5854@gmail.com', 'testing', 'Testing process.........................'),
(8, 'micel', 'micel@gmail.com', 'webApplication', 'i wanna make a website by you with in one week.\r\nif you are free then you would knock me by email\r\nthank you.');

-- --------------------------------------------------------

--
-- Table structure for table `footer`
--

CREATE TABLE IF NOT EXISTS `footer` (
`footer_id` int(12) NOT NULL,
  `address` varchar(100) NOT NULL,
  `number` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `description` text NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `footer`
--

INSERT INTO `footer` (`footer_id`, `address`, `number`, `email`, `description`) VALUES
(2, 'PATHAPATH,DHAKA', '01759998001', 'saifulsaif5854@gmail.com', 'Donec quis tincidunt nisl. Mauris ac urna libero. Aliquam cursus, augue eu efficitur dignissim, risus mauris porta diam, in bibendum lectus enim vitae risus. Maecenas sit amet pretium quam, in tristique ante.');

-- --------------------------------------------------------

--
-- Table structure for table `header`
--

CREATE TABLE IF NOT EXISTS `header` (
`header_id` int(20) NOT NULL,
  `logo` varchar(222) NOT NULL,
  `title` varchar(111) NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `header`
--

INSERT INTO `header` (`header_id`, `logo`, `title`) VALUES
(2, 'SaifulSaif', 'HELLO,MY NAME IS SAIFUL');

-- --------------------------------------------------------

--
-- Table structure for table `main_portfolio`
--

CREATE TABLE IF NOT EXISTS `main_portfolio` (
`id` int(66) NOT NULL,
  `main_portfolio_photo` varchar(200) NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `main_portfolio`
--

INSERT INTO `main_portfolio` (`id`, `main_portfolio_photo`) VALUES
(1, 'http://localhost/Portfolio/assets/img/portfolio/portfolio1.jpg'),
(2, 'http://localhost/Portfolio/assets/img/portfolio/portfolio2.jpg'),
(3, 'http://localhost/Portfolio/assets/img/portfolio/portfolio3.jpg'),
(4, 'http://localhost/Portfolio/assets/img/portfolio/portfolio4.jpg'),
(5, 'http://localhost/Portfolio/assets/img/portfolio/portfolio5.jpg'),
(6, 'http://localhost/Portfolio/assets/img/portfolio/portfolio6.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `service`
--

CREATE TABLE IF NOT EXISTS `service` (
`service_id` int(22) NOT NULL,
  `title` varchar(100) NOT NULL,
  `description` text NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `service`
--

INSERT INTO `service` (`service_id`, `title`, `description`) VALUES
(2, 'Web Design', 'Praesent magna neque, dapibus sit amet eros sed, aliquam interdum felis. Nulla rhoncus ipsum dui.'),
(3, 'CODING', 'Praesent magna neque, dapibus sit amet eros sed, aliquam interdum felis. Nulla rhoncus ipsum dui.'),
(4, 'Photography', '\r\n\r\nPraesent magna neque, dapibus sit amet eros sed, aliquam interdum felis. Nulla rhoncus ipsum dui.'),
(5, 'Clean Code', '\r\n\r\nPraesent magna neque, dapibus sit amet eros sed, aliquam interdum felis. Nulla rhoncus ipsum dui.');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_admin`
--

CREATE TABLE IF NOT EXISTS `tbl_admin` (
`admin_id` int(11) NOT NULL,
  `admin_name` varchar(222) NOT NULL,
  `admin_email_address` varchar(100) NOT NULL,
  `admin_password` varchar(50) NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `tbl_admin`
--

INSERT INTO `tbl_admin` (`admin_id`, `admin_name`, `admin_email_address`, `admin_password`) VALUES
(1, 'saiful', 'admin', '123456789');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `about`
--
ALTER TABLE `about`
 ADD PRIMARY KEY (`about_id`);

--
-- Indexes for table `contact`
--
ALTER TABLE `contact`
 ADD PRIMARY KEY (`contact_id`);

--
-- Indexes for table `footer`
--
ALTER TABLE `footer`
 ADD PRIMARY KEY (`footer_id`);

--
-- Indexes for table `header`
--
ALTER TABLE `header`
 ADD PRIMARY KEY (`header_id`);

--
-- Indexes for table `main_portfolio`
--
ALTER TABLE `main_portfolio`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `service`
--
ALTER TABLE `service`
 ADD PRIMARY KEY (`service_id`);

--
-- Indexes for table `tbl_admin`
--
ALTER TABLE `tbl_admin`
 ADD PRIMARY KEY (`admin_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `about`
--
ALTER TABLE `about`
MODIFY `about_id` int(23) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT for table `contact`
--
ALTER TABLE `contact`
MODIFY `contact_id` int(33) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `footer`
--
ALTER TABLE `footer`
MODIFY `footer_id` int(12) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `header`
--
ALTER TABLE `header`
MODIFY `header_id` int(20) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `main_portfolio`
--
ALTER TABLE `main_portfolio`
MODIFY `id` int(66) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `service`
--
ALTER TABLE `service`
MODIFY `service_id` int(22) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `tbl_admin`
--
ALTER TABLE `tbl_admin`
MODIFY `admin_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
